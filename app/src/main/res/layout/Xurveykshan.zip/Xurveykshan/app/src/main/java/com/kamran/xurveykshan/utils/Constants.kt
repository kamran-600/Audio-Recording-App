package com.kamran.xurveykshan.utils

object Constants {

    const val TAG = "LOGTAG"

}